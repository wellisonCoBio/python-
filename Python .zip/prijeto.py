import pandas as pd

# Classe para representar um produto
class Produto:
    def __init__(self, codigo, nome, quantidade, preco):
        self.codigo = codigo
        self.nome = nome
        self.quantidade = quantidade
        self.preco = preco

    def __str__(self):
        return f'{self.codigo} - {self.nome}: {self.quantidade} unidades, R${self.preco:.2f} por unidade'

# Classe para representar uma venda
class Venda:
    def __init__(self, codigo, nome, quantidade, valor_total):
        self.codigo = codigo
        self.nome = nome
        self.quantidade = quantidade
        self.valor_total = valor_total

# Função para cadastrar um produto
def cadastrar_produto(produtos):
    codigo = input("Digite o código do produto: ")
    nome = input("Digite o nome do produto: ")
    quantidade = int(input("Digite a quantidade em estoque: "))
    preco = float(input("Digite o preço por unidade: "))
    produtos[codigo] = Produto(codigo, nome, quantidade, preco)
    print(f"Produto {nome} cadastrado com sucesso!\n")

# Função para registrar uma venda
def registrar_venda(produtos, vendas):
    codigo = input("Digite o código do produto vendido: ")
    if codigo in produtos:
        produto = produtos[codigo]
        quantidade_vendida = int(input(f"Digite a quantidade vendida (em estoque: {produto.quantidade}): "))
        
        if quantidade_vendida <= produto.quantidade:
            produto.quantidade -= quantidade_vendida
            valor_total = quantidade_vendida * produto.preco
            vendas.append(Venda(codigo, produto.nome, quantidade_vendida, valor_total))
            print(f"Venda de {quantidade_vendida} unidade(s) de {produto.nome} registrada!\n")
        else:
            print("Erro: Quantidade em estoque insuficiente.\n")
    else:
        print("Erro: Produto não encontrado.\n")

# Função para gerar relatório de vendas em CSV
def gerar_relatorio_vendas(vendas):
    df = pd.DataFrame([vars(venda) for venda in vendas])
    df.columns = ['Código do Produto', 'Nome do Produto', 'Quantidade Vendida', 'Valor Total']
    df.to_csv('relatorio_vendas.csv', index=False)
    print("Relatório de vendas gerado: relatorio_vendas.csv\n")

# Função para gerar relatório de estoque em TXT
def gerar_relatorio_estoque(produtos):
    with open('relatorio_estoque.txt', 'w') as file:
        for produto in produtos.values():
            file.write(f'{produto.codigo} - {produto.nome}: {produto.quantidade} unidades\n')
    print("Relatório de estoque gerado: relatorio_estoque.txt\n")

# Função principal do sistema
def main():
    produtos = {
        '001': Produto('001', 'Mouse', 50, 25.00),
        '002': Produto('002', 'Teclado', 30, 100.00),
        '003': Produto('003', 'Monitor', 20, 700.00),
    }

    vendas = []

    while True:
        print("1. Cadastrar produto")
        print("2. Registrar venda")
        print("3. Gerar relatório de vendas (CSV)")
        print("4. Gerar relatório de estoque (TXT)")
        print("5. Sair")
        opcao = input("Escolha uma opção: ")

        if opcao == '1':
            cadastrar_produto(produtos)
        elif opcao == '2':
            registrar_venda(produtos, vendas)
        elif opcao == '3':
            gerar_relatorio_vendas(vendas)
        elif opcao == '4':
            gerar_relatorio_estoque(produtos)
        elif opcao == '5':
            break
        else:
            print("Opção inválida, tente novamente.\n")

if __name__ == "__main__":
    main()